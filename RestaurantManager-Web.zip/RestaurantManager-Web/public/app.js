// app.js
// Backend'e (server.js) bağlanan panel mantığı.
// Orijinal MainWindow / TableDetailWindow / MenuManagerWindow davranışını
// birebir yansıtır.

const API = '/api';
const CATEGORY_LABEL = ['Yemek', 'İçecek', 'Tatlı'];
const STATUS_LABEL = ['Boş', 'Dolu', 'Rezervasyonlu'];
const STATUS_CLASS = ['bos', 'dolu', 'rezerve'];

let menuItems = [];
let activeTableNumber = null;
let selectedMenuItem = null;

// ---------------- Yardımcılar ----------------

function tl(n) {
  return n.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' TL';
}

function toast(message) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2600);
}

async function api(path, options = {}) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = res.status === 204 ? {} : await res.json();
  if (!res.ok) throw new Error(data.error || 'Bilinmeyen hata');
  return data;
}

function openOverlay(id) { document.getElementById(id).classList.add('open'); }
function closeOverlay(id) { document.getElementById(id).classList.remove('open'); }

document.querySelectorAll('[data-close]').forEach(btn => {
  btn.addEventListener('click', () => btn.closest('.overlay').classList.remove('open'));
});
document.querySelectorAll('.overlay').forEach(ov => {
  ov.addEventListener('click', e => { if (e.target === ov) ov.classList.remove('open'); });
});

// ---------------- Saat ----------------

function tickClock() {
  const now = new Date();
  document.getElementById('clock').textContent =
    now.toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' }) +
    ' · ' + now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
}
tickClock();
setInterval(tickClock, 1000 * 30);

// ---------------- Ana ekran: masalar (MasalariCiz) ----------------

async function drawTables() {
  let data;
  try {
    data = await api('/tables');
  } catch (e) {
    toast('Masalar yüklenemedi: ' + e.message);
    return;
  }

  const floor = document.getElementById('floor');
  floor.innerHTML = '';

  data.tables.forEach(masa => {
    const card = document.createElement('div');
    card.className = `table-card table-card--${STATUS_CLASS[masa.Status]}`;
    card.innerHTML = `
      <div class="table-number">Masa ${masa.Number}</div>
      <div class="table-status">${STATUS_LABEL[masa.Status]}</div>
      ${masa.Status === 1 ? `
        <div class="table-meta">Kişi: ${masa.PersonCount} · Süre: ${masa.OturmaDakika} dk</div>
        <div class="table-total">${tl(masa.Total)}</div>
      ` : ''}
    `;
    card.addEventListener('click', () => openTableDetail(masa.Number));
    floor.appendChild(card);
  });

  document.getElementById('statTotal').textContent = data.stats.total;
  document.getElementById('statBos').textContent = data.stats.bos;
  document.getElementById('statDolu').textContent = data.stats.dolu;
  document.getElementById('statRezerve').textContent = data.stats.rezervasyonlu;
}

document.getElementById('btnYeniMasa').addEventListener('click', async () => {
  try {
    await api('/tables', { method: 'POST' });
    drawTables();
  } catch (e) { toast(e.message); }
});

// ---------------- Masa Detay (TableDetailWindow) ----------------

async function openTableDetail(number) {
  activeTableNumber = number;
  await refreshTableDetail();
  openOverlay('tableOverlay');
}

async function refreshTableDetail() {
  let masa;
  try {
    masa = await api(`/tables/${activeTableNumber}`);
  } catch (e) {
    toast(e.message);
    return;
  }

  document.getElementById('tdTitle').textContent = `Masa ${masa.Number} — ${STATUS_LABEL[masa.Status]}`;
  document.getElementById('tdSeatInfo').textContent = masa.SeatedAt
    ? `Oturma saati: ${new Date(masa.SeatedAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}  ·  Geçen süre: ${masa.OturmaDakika} dk`
    : 'Henüz oturulmadı';
  document.getElementById('tdPersonCount').value = masa.PersonCount || 2;

  const list = document.getElementById('tdOrders');
  list.innerHTML = '';
  if (masa.Orders.length === 0) {
    list.innerHTML = '<div class="order-empty">Henüz sipariş yok.</div>';
  } else {
    masa.Orders.forEach(o => {
      const row = document.createElement('div');
      row.className = 'order-row';
      row.innerHTML = `
        <span class="name">${o.MenuItemName}</span>
        <span class="qty">× ${o.Adet}</span>
        <span class="line-total">${tl(o.Toplam)}</span>
        <button class="remove" title="Çıkar">✕</button>
      `;
      row.querySelector('.remove').addEventListener('click', async () => {
        try {
          await api(`/tables/${activeTableNumber}/orders/${o.MenuItemId}`, { method: 'DELETE' });
          refreshTableDetail();
        } catch (e) { toast(e.message); }
      });
      list.appendChild(row);
    });
  }
  document.getElementById('tdTotal').textContent = tl(masa.Total);

  refreshProductSelect();
}

function refreshProductSelect() {
  const category = parseInt(document.getElementById('tdCategory').value, 10);
  const select = document.getElementById('tdProduct');
  select.innerHTML = '';
  menuItems.filter(m => m.Category === category).forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.Id;
    opt.textContent = `${m.Name} — ${tl(m.Price)}`;
    select.appendChild(opt);
  });
}

document.getElementById('tdCategory').addEventListener('change', refreshProductSelect);

document.getElementById('tdOpen').addEventListener('click', async () => {
  const personCount = parseInt(document.getElementById('tdPersonCount').value, 10);
  try {
    await api(`/tables/${activeTableNumber}/open`, { method: 'POST', body: JSON.stringify({ personCount }) });
    refreshTableDetail();
    drawTables();
  } catch (e) { toast(e.message); }
});

document.getElementById('tdReserve').addEventListener('click', async () => {
  try {
    await api(`/tables/${activeTableNumber}/reserve`, { method: 'POST' });
    refreshTableDetail();
    drawTables();
  } catch (e) { toast(e.message); }
});

document.getElementById('tdClose').addEventListener('click', async () => {
  if (!confirm('Masa boşaltılsın mı? Tüm sipariş bilgileri silinecek.')) return;
  try {
    await api(`/tables/${activeTableNumber}/close`, { method: 'POST' });
    refreshTableDetail();
    drawTables();
  } catch (e) { toast(e.message); }
});

document.getElementById('tdAddOrder').addEventListener('click', async () => {
  const menuItemId = document.getElementById('tdProduct').value;
  const adet = parseInt(document.getElementById('tdQuantity').value, 10);
  if (!menuItemId) { toast('Lütfen bir ürün seçin.'); return; }
  try {
    await api(`/tables/${activeTableNumber}/orders`, { method: 'POST', body: JSON.stringify({ menuItemId, adet }) });
    refreshTableDetail();
    drawTables();
  } catch (e) { toast(e.message); }
});

// ---------------- Menü Yönetimi (MenuManagerWindow) ----------------

document.getElementById('btnMenuYonetimi').addEventListener('click', async () => {
  await loadMenu();
  clearMenuForm();
  openOverlay('menuOverlay');
});

async function loadMenu() {
  try {
    menuItems = await api('/menu');
  } catch (e) {
    toast(e.message);
    return;
  }
  drawMenuList();
}

function drawMenuList() {
  const list = document.getElementById('menuList');
  list.innerHTML = '';
  menuItems.forEach(m => {
    const row = document.createElement('div');
    row.className = 'menu-row' + (selectedMenuItem && selectedMenuItem.Id === m.Id ? ' selected' : '');
    row.innerHTML = `
      <span class="name">${m.Name}</span>
      <span class="cat">${CATEGORY_LABEL[m.Category]}</span>
      <span class="price">${tl(m.Price)}</span>
    `;
    row.addEventListener('click', () => selectMenuItem(m));
    list.appendChild(row);
  });
}

function selectMenuItem(m) {
  selectedMenuItem = m;
  document.getElementById('mmName').value = m.Name;
  document.getElementById('mmCategory').value = m.Category;
  document.getElementById('mmPrice').value = m.Price;
  drawMenuList();
}

function clearMenuForm() {
  selectedMenuItem = null;
  document.getElementById('mmName').value = '';
  document.getElementById('mmCategory').value = '0';
  document.getElementById('mmPrice').value = '';
}

document.getElementById('mmAdd').addEventListener('click', async () => {
  const name = document.getElementById('mmName').value;
  const category = document.getElementById('mmCategory').value;
  const price = document.getElementById('mmPrice').value;
  try {
    await api('/menu', { method: 'POST', body: JSON.stringify({ name, category, price }) });
    await loadMenu();
    clearMenuForm();
  } catch (e) { toast(e.message); }
});

document.getElementById('mmUpdate').addEventListener('click', async () => {
  if (!selectedMenuItem) { toast('Güncellemek için listeden bir ürün seçin.'); return; }
  const name = document.getElementById('mmName').value;
  const category = document.getElementById('mmCategory').value;
  const price = document.getElementById('mmPrice').value;
  try {
    await api(`/menu/${selectedMenuItem.Id}`, { method: 'PUT', body: JSON.stringify({ name, category, price }) });
    await loadMenu();
  } catch (e) { toast(e.message); }
});

document.getElementById('mmDelete').addEventListener('click', async () => {
  if (!selectedMenuItem) { toast('Silmek için listeden bir ürün seçin.'); return; }
  try {
    await api(`/menu/${selectedMenuItem.Id}`, { method: 'DELETE' });
    await loadMenu();
    clearMenuForm();
  } catch (e) { toast(e.message); }
});

// ---------------- Başlangıç ----------------

(async function init() {
  try {
    menuItems = await api('/menu');
  } catch (e) { toast('Menü yüklenemedi: ' + e.message); }
  drawTables();
  // Oturma sürelerinin güncel görünmesi için orijinaldeki gibi 30 saniyede bir yenile.
  setInterval(drawTables, 30000);
})();
