# Restoran Masa Yönetim Sistemi (C# / Avalonia UI)

Bu proje restoranların masa ve menü yönetimi yapabilmesi için basit bir
masaüstü uygulamasıdır.

## ÖNEMLİ: Bu proje MacBook'ta çalışacak şekilde güncellendi

Orijinal proje **WPF** ile yazılmıştı. WPF, Microsoft'un sadece **Windows'ta**
çalışan bir arayüz teknolojisidir — macOS'ta hiçbir şekilde derlenip
çalıştırılamaz. MacBook'ta "açılmıyor" sorununun sebebi buydu.

Bu sürümde arayüz katmanı, WPF'e neredeyse birebir aynı mantıkla çalışan ama
**Windows, macOS ve Linux'ta çalışan Avalonia UI** kütüphanesine taşındı.
Uygulamanın iş mantığı (Models/Services klasörleri, JSON'a kaydetme, masa/
menü kuralları) hiç değişmedi; sadece pencereler (XAML → .axaml) ve
`MessageBox.Show(...)` gibi tamamen Windows'a özgü birkaç şey Avalonia'nın
karşılıklarıyla değiştirildi.

## ÖNEMLİ (2): Bu sürüm artık RestaurantManager-Web'e bağlı çalışıyor

Bu proje artık verileri kendi başına bir yerel `Data/*.json` dosyasına
yazmıyor. Bunun yerine, `RestaurantManager-Web` klasöründeki Node.js
sunucusuna (`server.js`) HTTP üzerinden bağlanıyor ve **aynı veriyi** onunla
paylaşıyor: Mac uygulamasında bir masa doldurulunca, web panelinde de
(sayfa yenilendiğinde / 30 saniyelik otomatik yenilemede) aynı masa dolu
görünür — ve tam tersi.

Bunun çalışması için **önce web sunucusunun çalışıyor olması gerekir**:

```bash
cd RestaurantManager-Web
node server.js
```

Sunucu `http://localhost:3000` adresinde çalışmaya başlar. Mac uygulaması
varsayılan olarak bu adrese bağlanır; farklı bir adres/port kullanıyorsan,
uygulamayı çalıştırmadan önce `RESTAURANT_API_URL` ortam değişkenini ayarla:

```bash
RESTAURANT_API_URL=http://192.168.1.20:3000/ dotnet run
```

Sunucu kapalıyken uygulamayı açarsan, masalar yüklenirken bir uyarı penceresi
çıkar ("Web sunucusuna bağlanılamadı..."); sunucuyu başlatıp uygulamayı
kapatıp yeniden açman (veya varsa bir "yeniden dene" eylemini tetiklemen)
yeterli.

`Services/ApiClient.cs` ve `Services/ApiConfig.cs`, bu HTTP bağlantısını
yöneten yeni dosyalardır. `TableService` ve `MenuService` artık dosya
okuma/yazma yerine bu istemciyi kullanır; iş kuralları (masa/menü mantığı)
tamamen sunucu (`server.js`) tarafında.

## Özellikler
- Başlangıçta 15 masa açılır, "+ Masa Ekle" butonuyla istediğin kadar
  masa ekleyebilirsin.
- Her masa; **Boş (yeşil)**, **Dolu (kırmızı)**, **Rezervasyonlu (turuncu)**
  olarak renkli kutularla gösterilir.
- Bir masaya tıklayınca detay ekranı açılır: kişi sayısı girip masayı
  "Dolu" yapabilir, sipariş ekleyip çıkarabilir, hesabı görebilir, masayı
  rezerve edebilir veya boşaltabilirsin.
- "Menü Yönetimi" ekranından yemek/içecek/tatlı ekleyebilir, düzenleyebilir,
  silebilirsin.
- Menü ve masa bilgileri `Data/menu.json` ve `Data/tables.json`
  dosyalarına otomatik kaydedilir.

## MacBook'ta VS Code ile Nasıl Çalıştırılır

1. **.NET 8 SDK**'yı kur (henüz kurulu değilse):
   ```
   brew install --cask dotnet-sdk
   ```
   veya https://dotnet.microsoft.com/download/dotnet/8.0 adresinden
   "macOS" (Apple Silicon ise **Arm64**, Intel Mac ise **x64**) sürümünü indir.
   Kurulumdan sonra terminalde kontrol et:
   ```
   dotnet --version
   ```
   `8.x.x` gibi bir şey görmelisin.

2. VS Code'da bu `RestaurantManager` klasörünü **File > Open Folder** ile aç.

3. VS Code önerirse **C# Dev Kit** (veya en azından **C#**) uzantısını kur.

4. Terminali aç (Ctrl+`) ve proje klasöründeyken paketleri indir:
   ```
   dotnet restore
   ```
   (İnternet bağlantısı gerekir; Avalonia paketlerini NuGet'ten indirir.)

5. Uygulamayı çalıştır:
   ```
   dotnet run
   ```
   veya VS Code'da `F5` tuşuna basarak (`.vscode/launch.json` ve
   `tasks.json` hazır).

> Not: Bu ortamda (bu sohbet içinde) internet erişimi ve .NET SDK
> bulunmadığı için kodu burada derleyip test edemedim. Kod, Avalonia'nın
> standart API'lerine göre satır satır WPF'ten uyarlandı; `dotnet restore`
> sonrası küçük bir hata çıkarsa (ör. paket sürümü uyarısı), hata mesajını
> bana gönder, birlikte hemen düzeltelim.

## Proje Yapısı
```
RestaurantManager/
  Models/                       -> Veri modelleri (değişmedi)
  Services/                     -> İş mantığı + JSON kaydetme (değişmedi)
  Program.cs                    -> Uygulama giriş noktası (Avalonia)
  App.axaml(.cs)                -> Uygulama tanımı (WPF App.xaml karşılığı)
  MainWindow.axaml(.cs)         -> Ana ekran
  TableDetailWindow.axaml(.cs)  -> Masa detay ekranı
  MenuManagerWindow.axaml(.cs)  -> Menü/fiyat yönetim ekranı
  SimpleDialogs.cs              -> WPF'teki MessageBox.Show yerine geçen basit pencereler
  Data/                         -> (ilk çalıştırmada otomatik oluşur) menu.json, tables.json
```

## Devam Etmek İçin: Eksik / Geliştirilebilecek Kısımlar
1. **Masa silme:** Şu an masa sadece eklenebiliyor, `TableService.cs` içine
   bir `MasaSil(int numara)` metodu eklenip ana ekrana "masa sil" butonu
   konabilir.
2. **Gün sonu / ciro raporu:** `RestaurantTable.Bosalt()` metodu çağrılmadan
   önce hesabı bir "geçmiş satışlar" listesine kaydedip, günlük/haftalık
   toplam ciro raporu gösterecek yeni bir ekran eklenebilir.
3. **Fiş / yazdırma desteği:** Hesap kapatılırken yazıcıya fiş basma
   özelliği yok.
4. **Kullanıcı girişi / yetkilendirme:** Şu an garson/yönetici ayrımı yok.
5. **Servis (garson) atama:** Masaya hangi garsonun baktığı bilgisi
   tutulmuyor.
6. **Adet azaltma:** "Seçileni Çıkar" butonu ürünü tamamen siliyor;
   1 adet azaltma / arttırma (+/-) butonları eklenebilir.
7. ~~**Çoklu bilgisayar / ağ desteği**~~ — bu artık çözüldü: veriler
   `RestaurantManager-Web` sunucusunda tutuluyor, Mac uygulaması ve web
   paneli aynı veriye HTTP üzerinden bağlanıyor (yukarıdaki "ÖNEMLİ (2)"
   bölümüne bak).
